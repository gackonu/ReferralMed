<?php if (!empty($errors)) : ?>
		<?php foreach ($errors as $error) : ?>
			<?= $error ?>
		<?php endforeach ?>
<?php endif ?>